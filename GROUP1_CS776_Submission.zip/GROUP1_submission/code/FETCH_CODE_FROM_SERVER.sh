#!/bin/bash
# Run this script on the lab server to fetch all code files into this directory
# Usage: bash FETCH_CODE_FROM_SERVER.sh
# Run from: /home/priyanka/GROUP_1_DLCV/Flight_GPT/

SERVER_BASE="/home/priyanka/GROUP_1_DLCV/Flight_GPT"

echo "Copying VG_HPM code files..."

# Main eval
cp $SERVER_BASE/VG_HPM/eval.py                                      VG_HPM/
cp $SERVER_BASE/VG_HPM/requirements.txt                             VG_HPM/

# navgym agents (our modified/created files)
cp $SERVER_BASE/VG_HPM/navgym/agents/CityNavAgent.py               VG_HPM/navgym/agents/
cp $SERVER_BASE/VG_HPM/navgym/agents/SubgoalTracker.py             VG_HPM/navgym/agents/
cp $SERVER_BASE/VG_HPM/navgym/agents/VSV.py                        VG_HPM/navgym/agents/

# navgym models
cp $SERVER_BASE/VG_HPM/navgym/models/CityNavData.py                VG_HPM/navgym/models/
cp $SERVER_BASE/VG_HPM/navgym/models/NavGym.py                     VG_HPM/navgym/models/

# navgym tools
cp $SERVER_BASE/VG_HPM/navgym/tools/EvalTools.py                   VG_HPM/navgym/tools/
cp $SERVER_BASE/VG_HPM/navgym/tools/ImgTools.py                    VG_HPM/navgym/tools/

# LLaMA-Factory configs
cp $SERVER_BASE/VG_HPM/LLaMA-Factory/examples/train_lora/vghpm_lora_sft.yaml \
                                                                    VG_HPM/LLaMA-Factory/examples/train_lora/
cp $SERVER_BASE/VG_HPM/LLaMA-Factory/examples/merge_lora/vghpm_merge.yaml \
                                                                    VG_HPM/LLaMA-Factory/examples/merge_lora/

echo "Copying FlightGPT_GeoPrior code files..."

# Future training scripts
cp $SERVER_BASE/FlightGPT_GeoPrior/run_sft_geo.sh                  FlightGPT_GeoPrior/
cp $SERVER_BASE/FlightGPT_GeoPrior/merge_sft_geo.sh                FlightGPT_GeoPrior/
cp $SERVER_BASE/FlightGPT_GeoPrior/run_grpo_geo.sh                 FlightGPT_GeoPrior/
cp $SERVER_BASE/FlightGPT_GeoPrior/eval_geo_trained.py             FlightGPT_GeoPrior/
cp $SERVER_BASE/FlightGPT_GeoPrior/open-r1-multimodal/src/open_r1/grpo_jsonl_citynav_geo.py \
                                                                    FlightGPT_GeoPrior/open-r1-multimodal/src/open_r1/
cp $SERVER_BASE/FlightGPT_GeoPrior/LLaMA-Factory/examples/train_lora/sft_geo.yaml \
                                                                    FlightGPT_GeoPrior/LLaMA-Factory/examples/train_lora/
cp $SERVER_BASE/FlightGPT_GeoPrior/LLaMA-Factory/examples/merge_lora/sft_geo_merge.yaml \
                                                                    FlightGPT_GeoPrior/LLaMA-Factory/examples/merge_lora/

echo "Done! All code files copied."
