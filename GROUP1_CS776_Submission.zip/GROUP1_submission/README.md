# GROUP 1 — Geographic Prior Injection for UAV Vision-Language Navigation
## Deep Learning for Computer Vision (CS776) | IIT Kanpur

**Extending FlightGPT with CityRefer-based Spatial Priors on CityNav Benchmark**

---

## Team Members
| Name | Roll Number |
|---|---|
| Kunal Jolly Saxena | 251110406 |
| Shrikant Sharma | 251110612 |
| Seetaramayya Lavu | 251110611 |
| Ankit Kumar | 252110607 |
| Harsh Sanjay Pandey | 251110035 |
| Anuj Singh | 251110403 |
| Shikha Yadav | 251110067 |

---

## Project Overview

We extend FlightGPT (EMNLP 2025), a UAV Vision-Language Navigation model, by injecting geographic landmark coordinates from the CityRefer database into the SFT and GRPO training pipeline. Our best result achieves SR=21.90%, OSR=37.86%, NE=66.14m, SPL=19.97% on CityNav test-unseen, improving Navigation Error by 13.2% over the baseline.

---

## Repository Structure

```
GROUP_1_DLCV/
├── Flight_GPT/
│   ├── VG_HPM/                          ← Main project directory
│   │   ├── eval.py                      ← Main evaluation script
│   │   ├── navgym/
│   │   │   ├── agents/
│   │   │   │   ├── CityNavAgent.py      ← Modified: get_prompt() with geographic prior
│   │   │   │   ├── SubgoalTracker.py    ← Created: passive subgoal tracking
│   │   │   │   └── VSV.py               ← Created: visual subgoal verification (passive)
│   │   │   ├── models/
│   │   │   │   ├── CityNavData.py       ← Episode data loader
│   │   │   │   └── NavGym.py            ← Navigation simulator
│   │   │   └── tools/
│   │   │       └── EvalTools.py         ← Metrics: NE, SR, OSR, SPL
│   │   ├── data/
│   │   │   ├── citynav/                 ← CityNav JSON splits
│   │   │   ├── cityrefer/
│   │   │   │   └── objects.json         ← CityRefer landmark database
│   │   │   └── training_data/
│   │   │       ├── vghpm_sft_v4.json    ← Original SFT training data
│   │   │       └── citynav_rl_data.json ← Original RL training data
│   │   ├── LLaMA-Factory/               ← SFT training framework
│   │   │   ├── data/
│   │   │   │   ├── vghpm_sft_v4.json    ← SFT data (LLaMA-Factory format)
│   │   │   │   └── dataset_info.json    ← Dataset registry
│   │   │   └── examples/
│   │   │       └── train_lora/
│   │   │           └── vghpm_lora_sft.yaml ← SFT training config
│   │   ├── open-r1-multimodal/          ← GRPO training framework
│   │   │   └── src/open_r1/
│   │   │       └── grpo_jsonl_citynav.py ← GRPO training script
│   │   ├── model_weight/                ← FlightGPT GRPO model weights (16GB)
│   │   ├── R1PhotoData/                 ← Training/test map images (50GB)
│   │   └── logs/                        ← Evaluation logs
│   │
│   └── FlightGPT_GeoPrior/             ← Future training setup (geographic prior)
│       ├── run_sft_geo.sh               ← Step 1: SFT training launcher
│       ├── merge_sft_geo.sh             ← Step 2: LoRA merge launcher
│       ├── run_grpo_geo.sh              ← Step 3: GRPO training launcher
│       ├── eval_geo_trained.py          ← Step 4: Evaluation for trained model
│       ├── data/
│       │   ├── map_params.json          ← Coordinate transforms for 29 city blocks
│       │   └── training_data/
│       │       ├── vghpm_sft_v4_geo.json    ← SFT data with geographic priors (90%)
│       │       └── citynav_rl_data_geo.json ← RL data with geographic priors (94%)
│       ├── LLaMA-Factory/
│       │   ├── data/
│       │   │   ├── vghpm_sft_v4_geo.json
│       │   │   └── dataset_info.json
│       │   └── examples/
│       │       ├── train_lora/sft_geo.yaml
│       │       └── merge_lora/sft_geo_merge.yaml
│       └── open-r1-multimodal/
│           └── src/open_r1/
│               └── grpo_jsonl_citynav_geo.py ← Modified GRPO with geographic prior
```

---

## Environment Setup

### Prerequisites
- NVIDIA GPU with 24GB+ VRAM (tested on RTX 4090)
- CUDA 12.x
- Anaconda/Miniconda

### Step 1 — Create Conda Environment
```bash
conda create -n dlcv_vghpm python=3.11
conda activate dlcv_vghpm
```

### Step 2 — Install Dependencies
```bash
cd /home/priyanka/GROUP_1_DLCV/Flight_GPT/VG_HPM
pip install -r requirements.txt
pip install vllm
pip install flash-attn --no-build-isolation
```

### Step 3 — Download Model Weights
Download FlightGPT GRPO model weights from HuggingFace:
```bash
# Install huggingface_hub
pip install huggingface_hub

# Download weights to model_weight/
python3 -c "
from huggingface_hub import snapshot_download
snapshot_download(
    repo_id='Pendulumclock/FlightGPT',
    local_dir='./model_weight'
)
"
```

### Step 4 — Verify Dataset
Ensure the following files exist:
```
data/citynav/citynav_test_unseen_easy.json    (2,096 episodes)
data/citynav/citynav_test_unseen_medium.json  (1,686 episodes)
data/citynav/citynav_test_unseen_hard.json    (1,529 episodes)
data/cityrefer/objects.json                   (landmark database)
R1PhotoData/                                  (map images ~50GB)
```

---

## Running Evaluation (Geographic Prior — Our Main Result)

### Step 1 — Start vLLM Server
Open a terminal (or screen session):
```bash
conda activate dlcv_vghpm
cd /home/priyanka/GROUP_1_DLCV/Flight_GPT/VG_HPM

screen -S vllm_server
CUDA_VISIBLE_DEVICES=0 vllm serve ./model_weight \
    --dtype auto \
    --trust-remote-code \
    --served-model-name qwen_2_5_vl_7b \
    --host 0.0.0.0 \
    --tensor-parallel-size 1 \
    --port 8000 \
    --max-model-len 32000 \
    --gpu-memory-utilization 0.85 \
    --enforce-eager
# Wait for "Application startup complete" then detach: Ctrl+A D
```

### Step 2 — Verify Server is Running
```bash
curl http://0.0.0.0:8000/v1/models
# Should return: {"data":[{"id":"qwen_2_5_vl_7b",...}]}
```

### Step 3 — Run Evaluation
```bash
conda activate dlcv_vghpm
cd /home/priyanka/GROUP_1_DLCV/Flight_GPT/VG_HPM

screen -S eval_geo
python eval.py 2>&1 | tee logs/geo_prior_eval.log
# Detach: Ctrl+A D
# Duration: ~25 hours for all 5,311 test episodes
```

### Step 4 — Monitor Progress
```bash
tail -f logs/geo_prior_eval.log
```

### Expected Results
| Split | SR | OSR | NE | SPL |
|---|---|---|---|---|
| Easy | 22.99% | 42.41% | 55.20m | 20.28% |
| Medium | 19.93% | 35.47% | 69.25m | 18.39% |
| Hard | 22.56% | 34.27% | 77.68m | 21.30% |
| **Overall** | **21.90%** | **37.86%** | **66.14m** | **19.97%** |

---

## Running SFT Training (v1–v4 Ablation)

### Train VG-HPM v4 (Best SFT)
```bash
conda activate dlcv_vghpm
cd /home/priyanka/GROUP_1_DLCV/Flight_GPT/VG_HPM/LLaMA-Factory

export CUDA_VISIBLE_DEVICES=0
export WANDB_DISABLED=true
export DISABLE_VERSION_CHECK=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

python src/llamafactory/train.py examples/train_lora/vghpm_lora_sft.yaml
# Duration: ~4 hours
```

### Merge LoRA Weights
```bash
python src/llamafactory/train.py examples/merge_lora/vghpm_merge.yaml
# Duration: ~10 minutes
# Output: saves/vghpm/merged_v4/
```

### Evaluate SFT Model
Restart vLLM server pointing to merged model:
```bash
CUDA_VISIBLE_DEVICES=0 vllm serve ./saves/vghpm/merged_v4 \
    --dtype auto --trust-remote-code \
    --served-model-name qwen_2_5_vl_7b \
    --host 0.0.0.0 --port 8000 \
    --max-model-len 32000 --enforce-eager
```
Then run `python eval.py` as above.

---

## Future Training: Geographic Prior SFT+GRPO

All scripts are in `FlightGPT_GeoPrior/`. Run in order:

### Step 1 — SFT with Geographic Priors (~4 hours)
```bash
conda activate dlcv_vghpm
bash /home/priyanka/GROUP_1_DLCV/Flight_GPT/FlightGPT_GeoPrior/run_sft_geo.sh
```

### Step 2 — Merge LoRA (~10 minutes)
```bash
bash /home/priyanka/GROUP_1_DLCV/Flight_GPT/FlightGPT_GeoPrior/merge_sft_geo.sh
```

### Step 3 — GRPO Training with Geographic Priors (~15 hours)
```bash
bash /home/priyanka/GROUP_1_DLCV/Flight_GPT/FlightGPT_GeoPrior/run_grpo_geo.sh
```

### Step 4 — Start vLLM with Trained Model
```bash
CUDA_VISIBLE_DEVICES=0 vllm serve \
    /home/priyanka/GROUP_1_DLCV/Flight_GPT/FlightGPT_GeoPrior/saves/grpo_geo \
    --dtype auto --trust-remote-code \
    --served-model-name qwen_2_5_vl_7b \
    --host 0.0.0.0 --port 8000 \
    --max-model-len 32000 --enforce-eager
```

### Step 5 — Evaluate (~24 hours)
```bash
conda activate dlcv_vghpm
cd /home/priyanka/GROUP_1_DLCV/Flight_GPT/FlightGPT_GeoPrior
mkdir -p logs experiment_geo
python eval_geo_trained.py 2>&1 | tee logs/grpo_geo_eval.log
```

---

## Key Modified Files and Their Purpose

| File | Change | Purpose |
|---|---|---|
| `VG_HPM/eval.py` | Added `_get_landmark_prior()`, CityRefer loading, fuzzy matching, disabled `tracker.advance()` | Main evaluation loop with geographic prior injection |
| `VG_HPM/navgym/agents/CityNavAgent.py` | Added `geographic_prior` parameter to `get_prompt()` and `act()` | Appends prior text to navigation prompt |
| `VG_HPM/navgym/agents/SubgoalTracker.py` | Created from scratch | Passive subgoal tracking (does not control navigation) |
| `VG_HPM/navgym/agents/VSV.py` | Created from scratch | CLIP-based visual verification (passive, disabled) |
| `FlightGPT_GeoPrior/open-r1-multimodal/src/open_r1/grpo_jsonl_citynav_geo.py` | Added CityRefer loading, `get_geographic_prior()`, prior in `get_prompt()` | GRPO training with geographic priors |
| `FlightGPT_GeoPrior/LLaMA-Factory/data/vghpm_sft_v4_geo.json` | Geographic prior injected into 90% of user messages | SFT training data with priors |
| `FlightGPT_GeoPrior/data/training_data/citynav_rl_data_geo.json` | Added `geographic_prior`, `top_left`, `px_real_size` fields | GRPO training data with priors |

---

## How Geographic Prior Works

```
Instruction: "A building near Livingstone Road with parking area"
                          ↓
           Extract: description_landmarks = ['Livingstone Road']
                          ↓
           CityRefer lookup: world coords = [348.4, 169.1]
                          ↓
           Coord convert: pixel = [917, 2310]
           using: pixel_x = (world_x - top_left_x) / px_size
                          ↓
           Inject into prompt:
           "[Geographic Prior] 'Livingstone Road' is at map pixel [917, 2310].
            The target building is located NEAR this landmark —
            search within ~400 pixels of this location."
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `CUDA OOM during training` | Reduce `image_max_pixels` in YAML config to `503520` (0.5M) |
| `vLLM server not responding` | Check `nvidia-smi` — kill zombie processes with `kill -9 $(nvidia-smi --query-compute-apps=pid --format=csv,noheader)` |
| `ModuleNotFoundError: navgym` | Run from the VG_HPM directory, not a subdirectory |
| `Geographic prior not found` | 32% of episodes have no CityRefer match — normal, model navigates without prior |
| `Low SR on first few episodes` | Episodes 0-2 always involve Leslie Road (383px from target) — known limitation |

---

## References

1. FlightGPT: Cai et al., EMNLP 2025 — https://arxiv.org/abs/2505.12835
2. CityNav: Lee et al., arXiv 2024 — https://arxiv.org/abs/2406.14240
3. Qwen2.5-VL: Bai et al., arXiv 2025
4. DeepSeek-R1 / GRPO: DeepSeek-AI, arXiv 2025
5. LLaMA-Factory: Zheng et al., ACL 2024
6. VLM-R1: Shen et al., arXiv 2025
